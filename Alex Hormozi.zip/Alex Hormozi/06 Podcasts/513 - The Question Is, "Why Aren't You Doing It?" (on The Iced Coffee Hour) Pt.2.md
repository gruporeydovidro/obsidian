We just need to strip away the perfection and get to the like, if I directionally move in this way over a long enough period of time, I will get there as long as I don't stop. Welcome to the game where we talk about how to get more customers, how to make more per customer and how to keep them longer, and the many failures and lessons we have learned along the way. I hope you enjoy and subscribe.

I have an interesting question for you. So in the last podcast, you mentioned that at one point in your life, you were religious. So what made you make that switch in your head from going from religion? Because I think you said you were on one of those trips.

I'm sorry, I forget what they're called. They're good. What made you switch that in your head to go from this very spiritual belief to almost the complete opposite of, like, life is life, we die, we die.

Fact is fact. Nihilism as a whole, what made that switch in your head? Or was it like, a long process? I mean, it was a very long process. It was five years.

And it was very, very hard for me. I will say this. The amount of messages I got from people who are Christian and Muslim and other faiths thinking that I attacked them on the last podcast, I don't know how I can make the you got messages.

Yeah. We didn't give yeah. And I will say this again.

My statements are not an attack on your religion. They are simply an expression of what conclusions I have come to. And I'll say right now, I'm wrong.

I'm wrong. You are right. Everyone listening to what you believe.

You're right. That being said, I was even going to, at the time, a Christian therapist, because I was like I wanted somebody who understood therapy but also understood Christianity so they could kind of work with me on these things. And after a handful of sessions, she just looked at me and she was like, alex, I think you just need to make a decision.

She's like, You've gathered all the data. You've gone to the courses. You did a college course on the formation of the canon, which is, like, how the Bible was actually put together, why things were put in, why things were not put in.

You've investigated all this stuff, and I was obsessing about it because I think, for me, until I understood why I was here, nothing else mattered to me. And some people, they can just walk through life without really thinking about it. In some ways, I'm jealous.

They can just do that. I couldn't I was like, Why am I working? Why do I care about money? What's the point of all this? That was always my first and most important thought, is, like, once we answer that box, then everything else kind of falls underneath of it. And so I think it's safe to say that there are very exceptional people who can make arguments on both sides in terms of, like, there's nothing, it doesn't matter.

And then there's really amazing apologists, like Ravi Zacharias, who's an amazing apologist, who's a Christian. There's just a ton of guys, right? And they're brilliant people, and you can listen to both sides of the arguments. But I think what ends up happening is that on some level, you have a belief.

And I'll rename that as an assumption because all beliefs are assumptions, but everyone has these assumptions, and at some point, you just have to say, like, okay, there's stuff on both sides. The jury has to pass a verdict, right? And to say that we have cracked it or like, Alex has cracked it, the deeper you go in these arguments, the more there are just other arguments that just continue to get pulled. And that's why I just fell into this rabbit hole where I was like, I need to start becoming a productive member of society because this is just going on forever.

And that's when she was just like, I think you just need to decide. And for me, the thing that felt more true to what I actually believed was that I didn't think any of it was real. And I think it was because that initially saddened me, and I didn't want that to be.

That's why I spent so much time trying to logic my way in to believing, because I do think it's a better life perspective to believe that there's capital M, meaning that there's somebody behind the scenes who's directing our lives so we can accomplish some greater goal right beyond ourselves. I just don't believe that. I wish I did.

I spent five years trying to I just don't believe it. And for everybody who messaged me and said, I really just need to talk to you for five minutes, please don't. I'm good.

I'm very content with my belief. And so for me now, I had to learn how to live with that belief and then kind of go from there, which is like, I don't believe that anything happens after we die. And my evidence for that is that I have been dead because I have not been alive.

And I know what it was like before I was alive, which was there was nothing. And I think that that's exactly what it'll be when I am not alive again. So to me, I'm okay with it, and that's fine, and I know I'm not, right? You know what I mean? That's just my two cent, Alex's.

Two cent on the world. And I think that people just need to figure out a belief. Like, whenever someone states a belief and they're like, well, I don't think that I'm like, cool, awesome.

As long as your beliefs serve you great, I'm pro you. It's interesting once you, I guess, got rid of the idea of or you didn't get rid of the idea of religion, but you just deemed it wasn't true for you. You described in the last episode that we did with you that you became nihilist.

Could you define nihilism for those watching? And also, once you did become a nihilist, how did that change your life? Did it change anything on the day to day? Or did it just basically reaffirm kind of what you already believed? Deep down? I think it crystallized thoughts that I already had. So it's like, you know how you have these thoughts that are ill defined or more amorphous, and once you put words to them, you're like, that's what I believe. Right? And so I think that once I understood, I didn't even know nihilism was the thing when someone was like, oh, you sound like you believe in that.

I was like, oh, but again, that's just the label. So people want to lock labels on things because it's easier for us to organize in our minds. But I just inherently believe that there is no capital M meaning.

That's it that's all I believe. It's just that there's no capital M meaning to what we're doing. There's little M meaning, as in, like, I find this meaningful.

I find this stimulating. I do things that I enjoy. Those are things that I find meaningful.

Little M. But is me doing this podcast big M universe meaningful. No, I don't think so.

Some people will disagree with me. That's okay. That's just my perspective.

And so in terms of how it shifted my life, it actually, in a lot of ways, dramatically improved my life. What was the worst thing for me was the indecision that five years was really hard for me because I felt like I couldn't make progress either way. I feel like I needed to either say, like, I'm all in.

I'm going all down the religious path. That's the game. Or I actually don't believe this.

And people could make the argument, well, there's probably a million shades in between. Sure, but for me, there wasn't. It was either this or this for me.

And so believing that there was no inherent meaning freed me from a lot of stuff. So this belief that I had to do what my parents said or listen to the opinions of others and be weighed down by judgments that I perceived to be there, which arguably probably weren't, right? Those were the things that it gave me relief from. And then the day to day anxieties of running a business, and like, this person stole clients from you.

And I'm like, when we die, it won't matter. It's okay. We'll move on.

It's just not going to matter. And that's why I share it, because there are probably other people who were in the same boat as me. And so I'm just sharing it for those people.

And if you're not one of those people, I love you, and that's awesome. I'm so stoked for you that you believe what you believe. But if you're not one of those people, I do think that giving yourself the freedom to have whatever little M meaning you want out of the activities that you do is incredibly freeing because you get to do what you define as meaningful, which is great.

I like that. Who do you look up to? Warren Buffett and Charlie Munger are probably my two heroes. Why? They've lived a life that I admire in a lot of ways.

I think that like and like my life goal was to be like King Solomon, just a wise man. And I feel like they are like modern day King Solomon. King Solomons in that they are wise.

They accumulated a lot of wealth and they did it living what I would consider Aristotle's, like good life. They did life their way and I just have a tremendous amount of respect for that and I have a lot of respect for Elon. I think it's more like the people that I look up to are people who are just authentically them and just do things their way.

And so that is what I try to do. And I think Nihilism actually helped me do that a lot because I wasn't trying to fit into a cookie cutter of like, you have to do these things this way, just much more like, I'm going to do this my way and that's okay, period. And that was very freeing for me.

And so I think those guys embody a lot of those traits. A really interesting thing that I read was a lot of us make heroes out of our own deficiencies. And so the people that we look up to are the people that embody things that we wish we had.

And so it's like being mindful of who you look up to is a great exercise in self reflection. It's like, why do I look up to these people? And it's probably because on some level I feel the most pressure of not being me. Right.

The pressure is around. I almost was in a hardcore religious person, I don't want to say susceptible, but I am swayed by those things. And so making the decision to choose not to do that, despite basically walking away from a community and all that stuff was very hard.

But it felt right to me and so I feel confident in the decision. Who do you look up to, Jack? Yeah. You, Graham.

I would say probably mainly just my parents, big idols of mine. Interesting. Is it? Yeah, I think that's interesting.

I think a lot of people don't look up to their parents because I think they live a perfect life. Wow. I don't know.

I really admire them. They're great people. I love their philosophies and I think they're super nice.

They're charitable, they're respectful, good people. It's great. They got a nice house too.

That's what it really was. Overlooks the beach. Jack's trying to get on the will right now.

I love you, mom and dad. You guys are the best. Seriously.

Just make sure to put me on Title, though. I love you way more than my brother. Yeah.

So was the view. Yes. If we're going to talk a great driveway.

Nice. Good driveway. If we're talking, like, big figures, great bones.

The house is good, I would say. I guess I like Elon Musk. I don't want to be one of those people that's just, like the classic person that just idolizes Elon Musk, but he's pretty awesome.

It's like saying LeBron is not a good basketball player because everyone says LeBron's a good battle. That's why I had no problem admitting that admirable that more people admit it has nothing to do with his excellence. Yeah, right.

It's hard for me to look up to people that I don't know super well. Fair. I suppose it's easier if I know someone through and through.

Anytime I picture people I admire, it's mostly the first things that come to mind are people that I'm familiar with. That's really interesting because I think for me, like, the entrepreneurial career path that I went on, it went from having mentors to heroes. And so mentors are people who like, as Lisa side of close proximity to kind of speaking to your life.

And I think as you continue to say level up and I say that loosely within the material success world, that's all I'm saying. There were fewer and fewer people in my close proximity that I was like, I look up to you because I feel like I've already kind of hit some of these check marks. And so I think that you end up moving up to finding your heroes and then that's like, Charlie Munger talks about this, where he has all his best friends are dead because it's like Benjamin Franklin and the people that he consumed all their stuff because they became his mentors.

And so I think that that, at least for me, was a shift that I feel like has continued to reinforce itself over time. The people I look up to are not in my life at all, but I still consume. I've been tremendously impacted by Warren and Charlie, even though I don't know them.

But you're saying once you check those boxes of the reasons why you looked up to these people, then you could no longer look up to them. Not look up to them. But trying to be mindful of how I say this, but I'll give a very quantitative example.

If I'm looking up to somebody for their physique or something, right. And then I achieve the physique that I want, then it's not that I don't look up to them, but I have understood the lessons. I don't need more lessons on this path.

I get it. But what if it's not something like it's more like of a mental thing? Like you look up to them for their philosophies or just their overwhelming understands the philosophies. He's just check that off.

Really. Richard Feynman talks about this where the point is not to memorize eyes, point is to understand it's. Like once you understand something, it becomes a part of you and you take it with you.

And you can apply it in a number of scenarios. And so if someone has something or a perspective that you don't have, the goal should just be to understand it so that you can take it with you. I actually really like that answer because I can relate a lot to that.

Because when I look at people, like when I watched people, for example, on YouTube when I was learning, let's say, photography, I didn't want to keep them as my mentor forever. Because then if I look up to somebody and I don't learn and I don't understand myself, then there will always be a deficit between my knowledge and their knowledge, if that makes sense. So I think it's always good to kind of want to understand things fully for yourself.

And I think there's also a sequence to knowledge. So this is actually kind of interesting. So if you think about when you learned math, because it's a simple example, right? Like, first you learned, like, simple addition, and then you learned multiplication.

And then when you went from your addition teacher, your arithmetic teacher, to your multiplication teacher, you weren't like, Screw my arithmetic teacher. There was so much better stuff out there. They were teaching me basics.

It's like, well, you had to learn that to learn the next thing, right? So it's not like I poo poo them. It's just that I no longer need that. I need the next building block.

And so I think that if you look at your life in those components of, like, maybe health and wealth and relationships and maybe spirituality, et cetera, you can look up to people who have an understanding of the topic. That is more in depth than your current understanding or has an understanding that you prefer to your understanding and then learn of them in that. And if someone just continues to have a more and more in depth understanding of it, which is why I think the higher up you go in terms of the people that you're looking at, the deeper their knowledge is on the subject, which gives you a longer period of time to continue to look up them.

Right, which is why it's natural that a lot of many people share the big public heroes because those big public heroes have such a depth of knowledge compared to everyone else that they can stay public heroes because a lot of people never surpass them or never fully understand what those people understand. But if you're close proximity, you assimilate the lessons and knowledge and knowledge and perspective from them, then you expand your circle. It seems from the outside that you've already kind of, like, optimized everything.

I don't want to say you're set in your ways, but you're confident in what you believe and what's optimal at this point. What can you work on? What's your biggest insecurity? It's a good one. Certainly not your hairline.

No. Certainly not lifting up your brim. I see that.

Man, oh, man. My biggest insecurity, it's probably the dual sided coin of ego and validation from others. I still am sensitive to the fact that I know that it still drives me, and I don't like that it does.

And so it's just, like, just consistently trying to just peel back the amount that it influences my decision making processes. The simple example is the content example. It's like, you make a video, you think it's awesome.

People think it sucks. And there's, like, two sides to that. One is like, you want to serve a marketplace, so you have to understand that part of it.

But the other part of it is, like, do I now suck? Right? Which is like, am I taking the performance of the thing and then projecting it onto myself? And I think that I still have a tendency to do that more than I'd be happy. I would prefer to not do that. I prefer to take the feedback objectively as it is and have 0% reflect back on me.

But I'm not at 0%. And so I think that's probably my biggest insecurity is the validation from others piece. I think I'm significantly better at it than I was, but I think it's still something that I want to work on.

Who do you seek validation from? Oh, it's just like the unwashed just the masses overall. Yeah. And as a quick rewind on the point that you were making earlier, I think I've inherited a lot of the character traits.

Not inherited, but actively tried to ascribe to a lot of the character traits, like Charlie Munger and Warren Buffett. And I think a lot of that is because when I look at old people, they have really good perspectives on things, and most of them don't care about most things because they realize that life is short. And so I'm trying to live my life as an old man for a longer period of time rather than waiting until I'm 70 to realize that it doesn't matter and I'm going to die.

It's just that I think once people get older and their death is looming, their priorities become much clearer. And I think inanity is the right word. Inanities of life become irrelevant.

Right. It's just like, who cares? That doesn't matter because life is literally too short for them. They literally don't have time for that.

And so trying to kind of project that into the present and trying to use an old man's wisdom in a young man's life is kind of my goal. But then what about a skill or something that you want to work on that you don't yet have, I feel like so I talk about this on my channel a lot, but there's three things that limit an entrepreneur, right? There's skills, there's character traits, and there's beliefs. And so the beliefs are some of the hardest ones because you're not aware of them, because you believe them, right.

We question all of our beliefs except for those that we truly believe, and those are everything to question, right? And so those are the three things in terms of improvement. So it's not necessarily just skills. It's also like, traits and beliefs.

I think that from a skill perspective, when I look at leverage a vehicle, I don't feel comfortable raising funds from other people. That would probably be the next natural piece to my business career, would be having some sort of fund structure for the investments that we're doing because we're obviously getting very good returns on them. There's part of me that I can see the value in the fund structure and helping other people participate in us, allowing us to do more deals, bigger deals, et cetera.

But there is a certain amount of autonomy that I enjoy having, not reporting to anyone. And so I wouldn't want the investors to become a new boss because that I know I would not like. And so I'd have to structure the right way.

But anyways, I think that is probably a skill deficiency that I currently have at least an in depth understanding of capital markets from the fundraising side. That's probably the skill that I need to work on the most in the probably three to five year horizon. Real quick, guys, if you can think about how you found this podcast.

Somebody probably tweeted it, told you about it, shared it on Instagram or something like that. The only way this grows is through word of mouth. And so I don't run ads, I don't do sponsorships, I don't sell anything.

My only ask is that you continue to pay it forward to whoever showed you or however you found out about this podcast that you do the exact same thing. So if it was a review, if it was a post, if you do that, it would mean the world to me and you'll throw some good karma out there for another entrepreneur. Got it.

Alex, you should ask some questions. Yeah. Tell me what you disagree with about what I said.

Alex. Yeah. You want me to disagree with more of your points? Oh, my God.

Yeah, sure. I don't know, because I don't think give us some either issues, problems or things in your life, Alex, that you want to work on or that you want to improve. My whole life, we didn't problem stuff.

We didn't do any of this. Oh, let's talk about that. You know what, Graham? That is a problem in my life.

Let's talk about that. So as you guys can tell by looking at me, I'm not the peak of physical fitness okay. But that is definitely a problem in my life that I think that I've neglected and I think that I could definitely use a lot of work on, and there's a lot of aspects to it.

But Alex, how do you do it to just conquer? Because, I mean, look at you, man. It's true. I noticed the jack walking is like, is that a tighter shirt? No, I just worked out this morning, and I'm thinking the same thing.

It's incredible. Thanks, man. I appreciate it.

Yeah, that's what I do it for. That validation. It would rip it.

Yeah, it's stretchy. That's the key, right? That's the key. So this is a good question, because, I mean, I did this.

I dedicated the first half of my professional career to this. And I would say that the nice thing is that the fitness weight loss thing is a question that has a lot of roots that can apply to other things. It can apply to personal finance, it can apply to fitness, it can apply to marriage.

The concepts of how you fix it are the same. And so I would ask you a question back, which is, Alex, what do you think you should do if you wanted to be better than you are right now? What would you do in regards to fitness? Sure. I already know what to do, I guess, right? Yeah.

So the real question is not what do I need to do? Because you already know what to do. The question is, why aren't you doing it? Yeah. So how do I answer that question? Because I was talking to Graham about this the other day, and I'm going to get really personal here, guys.

I told Graham that at the weight that I met, and luckily, I'm comfortable to talk about this, so please don't hold back. And I might be putting myself in a box here, and I hate to do this, but I'm speaking openly. I feel like at my weight, you don't get to my weight by having a small problem.

Right. I think there's some sort of emotional problem, whether it's something like either an addiction to food or some sort of how much do you weigh right now? If you're comfortable saying it, I'll ask you a better question. Okay.

Why aren't you £200 heavier? Probably because I can't eat that much. So you do know how to stop. Yes, I believe so.

Here's what's interesting. You do know how to stop. It's just that you don't have an issue.

You just stop at the wrong point. So it's not like I can't stop it. You can stop because otherwise you'd be £200 heavier.

Can you explain that a little more? So a lot of people were like, I have an issue. I'm binge eating. I can't stop eating once I start, et cetera.

It's like, okay, well, then why aren't you twice as big? Well, I can't eat that much. Cool. Okay, so you do know how to stop.

We just need to shift when you stop. Right. But again, that's only to break that belief.

The real real is becoming rather than thinking about the doing. Right. So you've probably heard the B do have, right? You have to be a certain type habits and how we create our identities are self reinforcing, right? We do certain things.

And because we do those things, we believe certain things about ourselves, right. And because we believe certain things about ourselves, we do certain things. Right? And so it's a constant reinforcement loop.

And so one of the telltale signs of somebody who's not going to be successful is like, oh, I'm trying to lose weight. It's like, no, that's not because they've already identified themselves as somebody who's not going to lose weight. And so we just need to wait for them to fail.

Right? Because you're saying, this is outside of myself. I have to push myself to get there rather than thinking, like, I want to become a healthy person. And so when you are confronting the many hundreds of decisions that you have every day, rather than trying to zone in on the super tactical of like, I have to weigh this and I have to count this and whatever, it's just simply like, what would a healthy person do in this scenario? Like, at every point, just like, what would a healthy person do? It's like they would do this.

Okay. And the thing is, you're not trying to be necessarily right. You just want to be less wrong than you are right now.

Yeah, that makes sense. I think maybe that's where I kind of had a downfall because there was a point where I did commit to weight loss. And in my head, I guess I wasn't right.

But in my head, I committed that this is a lifestyle change, right? It's with me for the whole life, and I lost £45, which for me that was a lot. But for some reason and it was all that was in my head, like, every day when I would wake up, it would be like a conscious choice of what I was eating, blah, blah, blah. But the thing is, it became so I don't want to say I don't know if it was toxic, but it became so.

I'm going to use the word toxic. That's all I thought about in my head. And I don't know how to go back there without doing that again because that part was so detrimental to my health.

But obviously so is eating. Yeah, they're both bad. But the thing is, I think you can take a season and not project it forever, right? So it's just for now, you will have this kind of obsession around eating food.

And that's okay because you're making a behavior change. Right. It's good that it's at the front of your mind.

That is what is creating the change. After you do that, for. A year or two years or three years, it will stop being as important because you'll do it without thinking about it, and then it's not going to be a thing.

But most people who have really exceptional physiques, we're obsessed with it for a period of time. Most people have exceptional marriages. We're obsessed with it for a period of time.

People have really good personal finances. We're obsessed with it for a period of time. And then there's just so many things that you don't even think about.

Well, of course use whatever apps use. Of course I don't go out to I don't get appetizers when we go out. Of course I don't buy name brand stuff.

It's just obviously but in the beginning, you have to put active attention because it's not normal. The goal is just to get the activities that you're doing to become kind of unconscious competence, which is like, you're doing them without thinking about them, so they don't actually take willpower because this is how you've always done it. But you have to get through the part where it's not how you've always done it, and so you have to allocate more attention to it.

Judging yourself on the fact that it was, quote, obsessive is like, so what? But I think it's the toxic, it's the mentality. Alex right. So why was that toxic for you? What made that impactful? It was literally distracting me from my work.

I would sit there and I would be working, and all I can think about was like, okay, at 05:00 p.m., I obsessed with the numbers. This is good.

I think it's important to know this. I knew how many calories the next meal I was eating, at what time, how many calories I have left for the day, because I was so focused on trying to be in a caloric deficit, which is obviously, like, the key to losing weight. But I would be working and I would just think about it, and then it would, like, pull me out of my work.

And, you know, like like Alex said, I mean, maybe it was a good thing. And then eventually I stopped following what I was doing, which I, in hindsight, obviously, I wish I didn't, but that's why it became, I think, a problem for me. Graham yeah.

Alex, wouldn't you say it's better this alex defined the root cause of the issue, like, to go deeper and say, this is why I'm eating a certain way. This is what maybe caused it. And solving that underlying issue would kind of help everything else, rather than just focus on the surface level.

Calories in, calories out. Yeah, I hear what you're saying with the question. I think a lot of us because if we have a big problem, we want to find a big root cause, and sometimes it's not.

And I think that we have to give ourselves permission for, like, maybe just food tastes good and we're evolutionarily designed to have a super stimuli when something is salty and fatty and sweet at the same time. And so we've gotten very good at pushing our own buttons. And so just saying, yeah, this is not because in some ways it becomes this huge beast that I have to defeat.

When we said this huge emotional issue and I had my kid, my parents, and when I was a kid and I would eat ice cream and that's how I felt good. You tell yourself these stories, but I don't know how useful it is because then it just exaggerates the size of the problem rather than just saying like, I am going to be a healthy person and make decisions that are in accordance with that. And a healthy person, if they ate out once, wouldn't be like, oh, I guess I'm not a healthy person anymore.

They would just do better. They would just go back to normal the next day. And so you can start whenever, as long as you start changing how you identify yourself.

I think that's just like that's the root of the stuff is like how do you identify yourself? And then you act in accordance with that identity. Like, if you are always like, I've just always struggled with my weight. Well, then that's what you identify with.

And so you're just going to reinforce that identity. So we have to switch that. There's a great book on this James Clear Talk.

It's atomic habits. Really good. But you're going to live in accordance with that and so you have to stop identifying with the things that are not serving you.

I agree. I don't know what to say. What's holding you back, Alex? Gosh, we're going deep.

I really don't know, to be honest with you. Why wouldn't you start today? There's no reason. So we could do that, but there was nothing holding me back yesterday or the day before.

Just a decision. Yeah, exactly. So you can make the decision whenever you want.

Yes, but I think it's a hard decision, I guess. Why wouldn't you do it today? There's literally no reason. Well, there is a reason because you're not doing it.

So why wouldn't you do it? Why are you not doing this right now? Because there's literally no reason. Well, maybe there is, like you said, but there's none that I can yeah, I think the reason would be that Alex feels like he could do it at any time. So why start today? Because I think it's easier to start next week or the week after.

And I know this because I'm very much the same. Yeah, I agree with that because I feel like it's my choice. But then that's so stupid because when I now sitting here, I'm like, well, I also had the choice to start it a year ago.

Right. Doesn't it get to the point where all of a sudden the pain exceeds the pleasure and I don't think Alex has gotten to a point yet where it's painful, it's maybe uncomfortable, but I think starting now is more uncomfortable than just you might have to get bigger. What? Yeah, you might have to get bigger to get there.

At the end of the day, you just have to hit your version of rock bottom. For me, my version of rock bottom is like 15% body fat. And so for me, I'm like, what am I doing? I look at myself and I'm like, just do piece of shit.

Come on, don't eat like an asshole. And then I got my shit together. And so the only difference between how people look is just where they draw the line to where they feel like an asshole.

All you're doing is just like saying, I feel like an asshole if I have above 10% body fat. There's tons of people who live there. There's some people who are like, that line is 20%.

That line is 30%. But what's crazy is that once you find maintenance, you just maintain the same way. So it's like, for me, I'd think why would you not maintain it good rather than maintaining it normal? Because all you have to do is get there once and then you just maintain it.

So anyway, that's Alex's perspective. But that's also because I came from somebody who really wanted outside validation. And so the easiest and first place to start for me was my body.

So I started lifting when I was 13 years old. So I'm like almost 20 years in this game in terms of the lifting and health and stuff. And so for me, this is not like we talked about it at dinner last night.

It's like this is not in any way time consuming for me mentally because I am a healthy person and I do these things because that is who I am. And so it is not very difficult for me. It's just difficult for people to make the change.

And I know the quote you were saying, which is change occurs when staying the same exceeds the pain of change. Right? And so it's like if your current existence hurts more than the discomfort that you will go through, then you will go through the new discomfort to get out of the current pain. Right? There's a million ways you can do it.

And that's why when you say, like, the root issue, it's like there's lots of tiny cues in Alex's environment that reinforces current behavior. It's not one thing. It's like what's in the pantry is and he walks in the door just like all of these tiny little things.

So you can change someone's environment. And I'll tell you an interesting one that I actually read in James Clear's book. So heroin is very hard to get off of, and that's a statement of belief.

But I'll just bear with me. In Vietnam, I think it was 15%, and then later they thought it was 20% of guys who went there tried heroin. Insane.

That's an insane statistic. And what was interesting about that is that when those Vietnamese now became veterans and came back, 90% of them never did it again. And the reverse statistic is true of, like, US.

Based addiction programs, right? 90% of people do heroin again after they leave the program. So how can you have the most addictive substance, right? And you've got a 90% success rate in one incident, and then you've got, like, a 90% failure rate in the other. And this one wasn't even a program, and this one was right.

And so what happens is, people, if you can pull someone out of the environment entirely, it's actually much easier to do because it's like you hang out with certain people and they reinforce those behaviors. You have cues in your environment that you've associated with which reinforce the behaviors. And so if you really went all in on something like this, and you could apply this to any type of behavior, whether it's drugs or food or whatever, is like honestly just changing everything about your life and then starting from scratch is like, I'm making these big changes.

I'm burning the boats. I'm being this person, and I will make these choices as a result of this. In accordance with that is sometimes the best way to do it is like clean slate.

But that might sound like a lot of change. And so you can also just not do any of that stuff and just eat less. But it's just tackling the big issue, which is, like, why you don't care.

I'd say one of the biggest things like you guys are saying, where what is it? The discomfort of the environment is so bad that it forces change, and the discomfort of going through it is easier. I will say I've had situations where going on a plane, for me, terrible experience, right? Just stuff like my wife probably wants to go parasailing if we go on vacation, I probably can't do that. And it's just like, I feel like there's a lot of life that I'm missing out on, and I've thought about it so deeply that I've cried about it before, but apparently it's not hard enough to change me.

But I don't know if I need to hit rock bottom for me to make a change. That's great. That's a great statement, because it is a good statement of belief to say, I don't need to hit rock bottom to make a change.

I agree with that. I think that is a belief that serves you. Yeah.

I don't know how to just click it. I really don't. Well, you just start, that's all.

There's nothing complex about it. You just start. You go home, you take away the stuff that you eat, that's not good.

That's it. At the end of the day, you've got to be ready, and we're not going to talk you into it, right? If you not being able to live half of the life is not sufficient, then you got to find something that is. A good friend of mine ran a super marathon, and it was, like, extremely difficult for him.

And he said, I think, on social media, he was like, I said, a big bag of whys? So he didn't just have one, why he had to have a huge bag of just like, you just pull out why after y, after y, after y to keep him going through this thing. And so maybe you don't need one. Why? Maybe you need a lot of wise.

Maybe you don't have enough wise. Do you need enough wise? I mean, at the end of the day, this change is yours. You've got to make it.

And it's when the reality of the condition is real for you. It breaks my heart. It really does.

I mean that in the most sincere way. My mother was super overweight my whole life, and she just recently, in the last two years, she's now in her 60s, like, my whole life super overweight, like, morbidly obese in the last two years. And for me, that might be an easy wife for me, is like, I don't want to live that easy.

Boom. Not even a thought to me, right? But when her physician and mind you, my mother is a physician, so, like, crazy, right? It was only when her physician, after trying, you know, she tried all these diets for whatever it was, when she was like, you're not going to see your grandkids. Like, 0% chance, it's not going to happen.

You're not going to see them. You're going to die before that, there's no question. And it was only in that moment that she decided to really do it, and she always knew what to do.

Eat less, walk more. It's not rocket science, right? But for her, that was enough. That whenever she was confronted with decision, because you have 100 micro decisions that happen every day.

Am I going to take the stairs? Am I can take this? Am I going to walk? Am I going to do it? Am I going to grab this extra bag or not? Or whatever it is? And so I think it's like, if you have that at the root, you'll be able to make the change, and then that will get you through the discomfort phase so that you can change your identity. And I love this again, I read this in the Atomic House book, which is really good. But if you look at identity, it's the root of two words.

You've got entity. There's the Latin version of it, but basically being and then you've identified, like, identical, which is repeated. And so identity is literally repeated being it's what we repeatedly do is who we are.

When you describe somebody, you're like, he's that person who X, Y, and Z's, right? That's how we even describe identity is what people do. And so the nice thing is that you don't win the vote of identity all at once. It's just one vote at a time.

And the beautiful thing is that you can just be like 51%, just like a vote. If you just do a little more, you win. You don't have to be perfect.

You just have to do more than you do bad. And if you do that for a long enough period of time, it will continue to reinforce itself. And so a lot of people have a binary vision of what, quote, perfect health style them looks like.

And that's silly and it's a farce. And it'd be like trying to pretend like you're going to be a perfect human. It's not going to happen.

Right, but you could also redefine healthy as just somebody who just doesn't binge. You know what I mean? You already know the stuff. So there's no point even getting in the tactics of this because it's just behavior change.

I probably went too deep on that, but it breaks my heart. But it has to break your heart. Yeah.

I think for me, okay, yeah. Some people have different reasons for why they're not currently doing it, right. For me, I have the knowledge, right.

I research into what I need to do, blah, blah, blah. In my head, to be honest, I'm ready to make the change. But the one thing I think that is holding me back the more I think about it is the feeling of like I don't know how to describe it other than impostor syndrome.

Right. And maybe this is just stemming from confidence issues. What really makes me think that I can do this and I think that is my biggest hurdle probably, and I don't know how to overcome that.

Here's something cool. You don't need to be confident to do this because your calories don't care if you're confident. Yeah, but for you, no, calories don't care if I'm confident or you're confident or anyone's confident.

Calories do not care. No, I understand that, but I mean, in my head I need to be confident about it to follow that statement. That's a statement of belief.

So why try? Because I'm going to fail. That's it. But it's one of those things where you can't let the past burn you twice, right, which is like if you failed in the past, if you project that failure into the present, then that past failure continues to repeat itself by you don't even trying.

It's like if we're looking at a kid who's walking, right, and they fall, we're not like I think it's just going to be a crawler. We don't say that. Right.

But right now you're applying that same you say so much worse things to yourself when it's like if you failed, so what? It's a process. You're going to learn to walk. You'll learn to walk eventually as long as you don't stop that's true.

So basically what you're saying is if I'm not trying, even if I'm trying and failing, basically it's better than just sitting here and being like, well, I'm not going to start because I'm going to fail. When we say yes, you're going to fail, expect failure. It's like starting a business.

Of course you're going to fail. That is part of the game. But saying that you stop doing something versus failing are very two very different things.

If you eat a pizza one day, right, but then the other rest of the week, you're fine. Did you fail? No. Right.

So it's like we just need to read. We just need to strip away the perfection and get to the like, if I directionally move in this way over a long enough period of time, I will get there as long as I don't stop. That was great.

Yeah. Everything that you're saying is great. For some reason, it's just stuff that I don't think about it.

To be frank, you'd have to pull this thread, and I don't necessarily know that we have the time to do it on this podcast, but you have to figure out why your gut instinct was to say eating healthy was bad. Basically, if I were to make this, boil this down into simple terms, you're like, I started eating healthy and I decided it was bad. So it's figuring out why you made that experience bad in your head and figuring out because there's probably other things that eating does for you, it probably relieves stress.

Right? So it's like, great. And the nice thing is that there's lots of cues for stress in our lives. So you have a number of cues that trigger the behavior.

So it's not just one. It's like you can get stressed for a zillion things and then have a really easy because habits are created for mental shortcuts, so we don't have to make decisions. And so it's like, I feel stressed.

I can resolve this immediately with this thing. I don't even think about it. You're just starting to walk towards the fridge when you feel stressed, right? And so to break this, like, man, we're going to get way too deep into behavior stuff.

So I'll cut it at this, which is you got to figure out why you didn't start yesterday. And there's a reason that you have and you need to name the reason. And it may be ridiculous.

Some people are like, it's just not convenient. Cool, then make it convenient. And then all of a sudden, sometimes it's the tiniest thing.

I'll tell you this tiny example, which is I try and put face cream on every night before I go to bed. It's like one of the habits that I really was like, I'm going to try and do this right. And when the mates come sounds ridiculous.

When the mates come to clean our place, I have my bedside set up and then they take all my stuff that's, like, right next to me, and then they move it along the back line of the bedside table. So the cream is, like, over a box, and it's hard to reach, and when I'm in bed, I can't reach it. And I had to realize it because I was like, I'd get on a good routine, and then, like, two or three days in, I would stop doing it.

And then I realized the only reason I stopped doing it was because I didn't see the cream. And if I did remember the cream, it was like, I would have to get out of bed to go grab it and then put it back. And so I had to tell the maids, leave them along the side and don't move them.

It's the tiny, like, these tiny things, just like I had a visual cue, and it made it more difficult, so I removed the visual cue because it was further away, and then it got harder. Rather than making it easier and making it obvious. I think I have an answer for you, actually.

Okay. So the only reason that I thought about food all day in my, quote unquote, toxic behavior is because I was hungry. Yeah, you're not you're bored.

If you could eat a chicken breast, if you're like, oh, man, I could go for a chicken breast. You're hungry. If you're like, oh, I could go for a snack.

You're bored? I don't know. It felt like hunger, but yeah, of course. You don't know the difference.

Yeah, I don't know the difference. I don't know the difference. You learn the difference when you're really hungry.

You're like, Chicken sounds great, like, an apple sounds delicious, you know what I mean? But when you're bored, you're like, I could go for some chips, you know what I mean? If you could go for a chicken breast that's dry with no sauce, that's when you're hungry. I think you're 100% you probably haven't you know, I'm thinking about it. Guys, I know this sounds so you're right, it sounds stupid.

It sounds so stupid. But, like, in my head, right until you said that, I was convinced that I was hungry all the time. But now that you said that, I don't think I was hungry, and I know that sounds stupid.

You guys are like, probably you guys are probably laughing every I swear to whatever you believe in. A lot of the times where I'm snack, it's the dead space where you would normally reach for your phone. It's like, well, I may as well just eat a quick snack.

Alex, you haven't been hungry in years. You don't know what hungry. What are you trying to say about that? I'm saying that you've been overfeeding for a very long period of time, and so you have such a surplus and stores that your body can take from for a very long period of time.

Yeah, I agree. With you. I just had, like, an epiphany, I think.

I don't know. This is so crazy. I think I don't know the difference between being hungry and being bored.

I know that sounds stupid. No, it's fine. I think very few people know the difference between even me.

And you don't know the difference? Then why don't you look like me? Graham, what's up? If you don't know the difference, then why don't you look like me? You're pretty physically active. Yeah, I've been going to the gym quite a lot. My default is probably eating healthy.

But until I've started tracking calories, I've realized that I've eaten more than I've expected. But my default is still eat healthy, eat small portions, but without tracking it. I eat more than I think I do.

I just want to thank you for your time. I didn't mean to bring you on the podcast and bombard you with my physical physique questions or anything, but I'm sure there are other people who are listening who are dealing. You could replace this with alcohol.

You could replace this with whatever. It's the same thing. My mind is just blown right now.

Now I feel like I could do it. And I just want to just reinforce this one point, which is just because you are hungry does not mean you need to eat. So you used being hungry as a justification for eating.

You can be hungry and not eat. You can be horny and not have sex with money. It's not your wife.

So just because you have a feeling doesn't mean you need to take action on it. Right. So first we had to delineate between the fact that most of the time you're bored and not actually hungry.

But even if you are hungry, that doesn't give you permission to then go eat. Because if you diet, you will be hungry, actually, and a chicken breast will sound good, so it doesn't necessarily mean that you have permission to eat outside of what you think you need to hit for your calorie intake. Is it just like a mental thing at that point? You already know the calorie stuff.

There's no point in getting into that. If you really want to do it, you already know. You google it.

You know you need to eat less than you are right now. And you would just do that. You're just reminding yourself that you know how much you're supposed to eat.

And just saying, I have enough to live. It's just my body telling me you could right now, literally drink water and take a multivitamin for a year. There's no way.

I promise you. They've already done studies on this. You can absolutely do it.

I mean, I'm not going to, but that's fine. Yeah, but I'm saying you have more than enough stores to last you for a very long time. So the only thing you're doing to eat is just like you're just moving things through your system, but that's it.

They've done starvation studies and your basal metabolic rate goes down, but not by I mean, it goes down by 30%, which is something, but it's not massive. And you're still going to have a high bismobalic rate overall because you have more of you to feed and maintain. Like fat takes calories to keep alive.

You have fat on you, but it still requires blood and nutrients to stay alive. Right. To not become dead tissue.

So in a lot of ways, it's easiest to lose weight when you are bigger. So you can keep saying that as your refrain. It's like, I am bigger, which means it should be easier for me to lose weight because it is.

Yeah. I don't want to lay around this. You're good too long because I think we've gone long enough.

But seriously, I will come on. Thank you. Today the day, Alex.

I think so, but yes, it is. He kind of scared me with the like, you're going to be real hungry and I'm just like, oh, but you know what? I think I've just been eating because I'm bored. And I know people are going to think this is stupid.

Like, Alex, of course you were eating when you were bored. But to me, I'm telling you guys, I truly felt hungry in my head. That was hunger.

And thinking back, I don't think that was distract yourself and that was kind of stupid. You shouldn't be bored at work. That's a real issue.

But we'll talk about that after the podcast. I'm kidding. No, we're good.

Thank you. No, you bet. It's a blast to have you on, man.

Really appreciate it. I was really looking forward to this. Yeah.

Even going out to dinner last night, I genuinely enjoy hanging out. But it's listening to you talk, I learned so much and more than just like a friendship, but also just the fact that I feel like I am the student of so many things and being exposed to different thoughts and a different way of thinking and a different structure. Very few podcasts afterwards do I just want to be alone, and this is always one of them because I have so much to think about after we end this.

I appreciate it and thank you guys for having me on. I think it's chunking down and chunking up in terms of thought process, just like, why are we doing this? And I think that's just been the core of it. It's just like, why am I bothering to do this? Why does this matter? And so it does go back to my worldview.

It is the seed that kind of has borne all the fruit of the other things that I have. It's just like, why am I choosing to because it is an active choice. I'm glad that the thoughts that I've had have been at least thought provoking because they took me a long period of time to figure.

Out on my own, and I think they can be unique to different people. But for me that this set of beliefs has served me well know? I continue to believe them. Thank you for coming on.

And next time appreciate it. Thank you guys.