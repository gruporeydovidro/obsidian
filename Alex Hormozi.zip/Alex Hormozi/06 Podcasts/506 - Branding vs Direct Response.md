What's going on, everybody? I'm bringing some more books, but I wanted to say that if you haven't checked out 100 Million Dollar offers, I would definitely suggest that you start there. I've gotten some solid feedback and I couldn't be happier with its number one ranking on Amazon for direct marketing and over 5005 star reviews. So thank you guys so much for that.

It's 164 pages. I really can help you out. It takes about 4 hours to get through.

Check it out on Amazon. The Kindle book is ninety nine cents. The audiobook is as low as they'll let me put it on for it.

So it's $12. So enjoy that and let's start the podcast. But the longer you delay the ask, the bigger the ask can be.

Welcome to the game where we talk about how to get more customers, how to make more per customer and how to keep them longer, and the many failures and lessons we have learned along the way. I hope you enjoy and subscribe in this video. I want to break down the difference between branding and direct response marketing and why not deeply understanding the differences, costing you millions and millions of dollars and ultimately the amount of money that you probably want to make.

And if you don't know who I am, my name is Alex Mozi. I own acquisition.com. It's a portfolio of companies that is about $85 million a year in revenue and I have nothing to sell you.

All right? I make these videos because I was once broke and I've learned a lot of lessons along the way. And I don't want the pain that I experience to be in vain. All right? That's why I make these.

So that being said, branding versus direct response. I think this is one of the more interesting topics that I have dove into over the last year or so. And it's come from a variety of different conversations I've had with top marketers.

And this morning I had a conversation with Dean Graciosi, who is a phenomenal world class marketer. And we talked for like an hour this morning just about this concept of the difference between branding and direct response. And I thought I would share some of the lessons or discussion points that we had with you so that you can hopefully benefit.

And so the first point is that you may have heard this in my book, 100 Million Dollar Offers, but **the longer you delay the ask, the bigger the ask can be.** So for example, you can use this in any situation, whether you're courting a lady or a guy or whatever. You know, if in the first 5 seconds you're like, hey, let's go home together, it's like, well, you might have some audience that'd be willing to do that, but the vast majority of people would not be willing to do that.

But if you date for six months, then that might be something that would be almost everybody would be willing to do that after six months, depending on whatever relief beliefs. That's not my point here. But you can get the idea that a higher and higher percentage of people would be willing to take you up on that offer if they had spent more and more time with you.

And so the longer the delay, the bigger the ask. And the visual that I like to ascribe to this is the longer the runway, the bigger the plane that can take off, and so the bigger the payload you can get based on the amount you delay to the same degree. If you've seen Gary Vee, he's an influencer, and he owns a marketing agency out of New York, and he spent, I want to say, ten years or twelve years building his personal brand.

And then he finally had his ask, which was, hey, buy my NFT. And then within the span of six months, ended up making like $100 million from that NFT launch, right? Now, I would make the argument that the NFT launch itself was actually direct response marketing play, whereas everything prior to that was really about Brit building the brand, right? And so different examples of this that I think would be important to drive the point home. And why I think that many, many marketers start in direct response and then end up in branding is because of what I'm about to share with you.

So please listen closely to this. If you are trying to make more money, if you look at most big consumer brands, you look at Colgate or Crest or Shampoo brands that have been here for a very long time, they're not offering two for one deals. They're not like, hey, go buy this toothpaste for 50% off, right? That's not actually what they're doing.

They're just talking about the products. And if you look at some of these bigger celebrities that exist, you look at Dwayne Johnson the Rock built his huge brand and then said, hey, I'm starting this tequila. You guys should check it out.

Conor McGregor built up his personal brand that said, hey, check out Proper twelve. Kylie Jenner was like, hey, built up her brand, and then she did her Lip kits. And so what's interesting is that brand people are now realizing is an amazing arbitrage opportunity for maximizing value.

And I think part of the reason behind this is that goodwill compounds faster than revenue does. And so hear me out. Think through this with me.

If you've seen somebody who's consistently been selling, and this may be you, what happens is you provide value in some way, and then you extract the value that the equity in the relationship through monetizing it through an ask or some sort of right hook, as they say, just getting them to try and buy something, right? And the thing is that whenever you make an ask, you decrease your goodwill, right? And so you kind of have to start over at zero again, and then you build up goodwill, and then you ask, and then it goes back to zero again, right? So you're constantly depositing and extracting capital in the relationship, and the hope is that it costs you less to deposit than you make on the extraction, right? That's fundamentally what traditional direct response marketing is at its most basic form, right? And the reason it is direct response is that we are actively requesting a direct reply or immediate action as a result of seeing our advertisement of any kind. To contrast that with branding. What we're doing with branding is that we are reinforcing the values and the stories that people tell about our products and services, all right? So we're reinforcing stories versus asking for actions.

And you might be like, well, branding doesn't make sense. And I want to tell you this because when I started out my career, I thought that every single company that did branding was retarded. I was like, you guys are idiots.

If you guys understood how direct response worked, you guys would make more money. I'm such a genius, blah, blah, blah, blah. And I was wrong, as I often am.

And the more I studied these massive companies, I was like, okay, so all of these companies all do this type of marketing, whereas little old me is doing this quick jab, right hook, whatever, of just give, ask, give, ask, give, ask, give, ask, and always just depositing it enough value in order to extract the value later. And the thing is, people get it. People have seen it.

They know the game. And yes, it does work to a limited degree, right? But it's very, very rare to find a massive direct response company. I'm not saying they don't exist, but I would say the preponderance of enormous companies are not direct response based companies.

And so why is that?

And I would posit and this is my theory and this is what I talked to Dean this morning about at length is the difference between direct response and branding is not the ROI on the advertisement itself, but on the time horizon with which we measure it, all right? And so in direct response, you're always calculating your return on ad spend immediately, rather than thinking,

Can I build up this brand? And then look at the return you're getting on that brand overall over an extended period of time. And so I'll give you a classic example to illustrate the difference. If I were selling T shirts, a direct response marketer might have a cool, funny meme thing, aggressively market.

It have upsells of two of the same shirts, five of the same shirts getting on continuity for each meme shirt every month, blah, blah, blah, right? That would be a typical direct response marketing plane. Not to say you can't make money doing it. You can.

And this is the big exception I'm having here, right? Is that, like, you can become a millionaire doing small games. All right? So I'm not saying you can't do it. You absolutely can.

It's just that what type of game would you prefer to play? And I can say that as I've aged or weathered in the game, I continue to shift more and more towards branding. But I do think there's a balance that needs to be struck. But from a branding perspective, in that same example, it would be spending a year talking about what your values are, the stories that you want people to tell about you and your company, and then you can simply put your brand on a T shirt and people will pay $100 for it.

Right? And so then what is the return on the advertising you did for that year? Well, if you can sell T shirts for $100, rather than trying to arbitrage meme T shirts and discounts and bundling and doing all sorts of more complex things and just simply saying, if you believe what we believe, vote with your dollars about the things that you care about, right. Align with us. And that's fundamentally what branding is.

And when branding works very well, is when what you are saying about your brand clarifies what people are already saying. And so a lot of times, people have a general gist of what your brand is. Hopefully it's what you want.

Oftentimes it's not. And this is especially true in the direct response marketing community at large, because people say terrible things about the people who are doing their direct response. And so their brand is the reputation and the things that other people say about you.

Real quick, guys, if you can think about how you found this podcast, somebody probably tweeted it, told you about it, shared it on Instagram or something like that. The only way this grows is through word of mouth. And so I don't run ads, I don't do sponsorships, I don't sell anything.

My only ask is that you continue to pay it forward to whoever showed you or however you found out about this podcast, that you do the exact same thing. So if it was a review, if it was a post, if you do that, it would mean the world to me and you'll throw some good karma out there for another entrepreneur. In an example that Elon Musk gave an interview, I can't remember where he gave it, he talked about how the consumer is the one that creates your brand.

He said if you look at I think he gave the example of Toyota and Ford, but the point is not necessarily the brands, but more so, the message. Which is he said, listen, Ford talked about being reliable and being high quality, et cetera. He said, in Toyota, their marketing never said that.

And yet Toyota is the company that's known for being reliable and high quality and things like that, compared to the Fords. Right? He said so as much. You can say whatever you want in the marketing messaging, but it has to be true.

And so my interpretation of that is what you want to do is give people the words to describe your brand that are true and just give them the words to say rather than trying to redefine the thoughts they have. And I think that that is really what comes to effective branding and doing that deliberately. As an added point to that, this is something that I got from Grant Cardone, which has been one of the really deep and profound lessons I think I got from our two conversations we've had about marketing in general.

But one, first off, the many people who don't like Grant, you have to appreciate how effective he is at promoting himself and his brand. Like, you have to respect that. You cannot like the man, but you must respect what his level of effort and the outcome and the output of his effort.

Right. I personally have had nothing but positive interactions with the Grant, but my point is that you have to respect that. Now, that being said, one of the things that he said that I have really taken with me is the one or two words that someone will associate with your brand.

He said, when they think of me, I want them to think this, right? And that is not this massive declarative value statement or mission statement, because people don't care, right? Nor do they remember hardly anything. And so if you can get the masses to just remember, oh, yeah, he's the real estate guy, he's the business builder guy, right, which should be more aligned with what we do. We build businesses and we buy interest in information, coaching, elearning type businesses that are in a niche.

And that's what I want people to associate. Now, they're not going to remember all the stuff that I just said, but if they can just say, like, he's a digital business builder, digital business investor, either of those things would be things that I would say, okay, that's a positive association. That's the type of association that I want people to make with my brand, right? And the thing is that if I can wait a longer time, which is why most people cannot do this and why I'm not saying you necessarily have to start branding day one, but if you can be cognizant of what the message that you were relaying in your content and in the advertising that you do.

And I'm using advertising by the actual definition, which is to make known, right. When you make your products and services known in the many ways that you do it, if you can reinforce the simple message in every single thing, people will begin, as long as it's aligned with what's true, to say the same things back to you. And that will reinforce the cycle of who you are in the marketplace and what you stand for.

And so if branding is a higher ROI activity overall I believe it is, and I think that there's the many massive companies that exist out there would be great testaments. And evidence to that point is that they don't engage in direct response marketing for the most part or even at all to the vast like the vast majority of the time, they are talking much more about who they are and what they stand for, why they do what they do. Right.

And then people then buy their products and service in accordance with their values and they vote with their dollars about the things that they care about being the identity that they wish to associate with, right? And so I think that the reason Seth Godin started with Direct Response and then became and now talks exclusively about branding. The reason Simon Tind started Direct Response and then talks way more about branding.

The reason that I started in Direct Response and talk much more about branding stuff now. And at least that's my belief in where I think that it's because that's where you make more money just over a longer time horizon.

And I think the reason that many direct response marketers burn out is because they don't like the brand that they are building for themselves, which is why most people leave the space over a long enough time horizon.

And so that's why you don't see many I'm not saying there aren't any, but the vast majority of direct response marketers tend to be younger.

And one of the difficult things about this, and I was having a good conversation with a friend about this, is that because it is such a young space, there are not many people who have old lessons. And so the predominant education that exists in the space is people who are new. The fact that someone can consider themselves a, quote, OG in the Internet marketing space after three years is laughable, right? It's laughable, it's hilarious, but it's true.

In that space, it's very difficult to be an OG because most people burn out because their brand equity drops so much, right? And so if the only way that we can build very big things is doing them the same thing over a long period of time, then it would create, I don't want to say obvious, but a natural conclusion that branding is the direction that more people end up going in once they have the ability to do so. And so if you can delay the ask and you can have the resources and you can have the patience to build something bigger, your goodwill will compound faster than your revenue will in a direct response marketing environment. And so this is the concept around give, give, give, rather than ask, give, give, give, comma, give, give, give, comma, give, give, give, get.

And what's interesting is that I think most people and the prospects that are consuming your content and things like that. They are waiting for the other shoe to drop. They're waiting for you to make the ask.

And so they have their guard up. But if you give, give, give. And then right when they're expecting you to ask give again and then again and give even more, their guard begins to drop.

And then they start to think, man, this guy or this gal is awesome. I really like this person. And then something interesting happens.

They start telling people about you because they don't believe that they're sacrificing their own brand equity by sharing your message. And so that is where the compounding effects of word of mouth start to take off. And so when I say that goodwill compounds faster than revenue, it's because in the traditional example, it would be give, give, give, ask.

And this isn't me, poopooing Gary or anything like that. I mean, I think that very much at least establishing that cadence is useful for most people who are doing a direct response. At least give something before you ask, right? But if rather than asking right where you have to start over at zero because you build equity, you build value in the relationship, and then you asking you back down to zero, and then you build it, then you go back down to zero.

And then you're basically always capped by the amount of value that you have in the relationship. That's the cap, right? But the alternative, if you were to look at this visually would be give, give, give, give, give, give, give. And then it keeps going.

The chart keeps going off. And then at a certain point, a certain percentage of that audience because they are reciprocal in nature type people, they will take steps towards you without you even asking simply because they believe so strongly in what you have. And those are the types of clients that you want to be able to take on.

It just takes patience to get there. But when you have those types of clients, they get better results. They pay bigger premiums, and it also gives you implied scarcity within your products and services.

And you are always underselling your demand, which will essentially eliminate your bottleneck that you have in growing because you will always have more demand than you can possibly handle. And that is the benefit of building the brand over the long term rather than simply the one two punches in order to extract capital today. And so if you can delay the amount of time that you have between when you provide value and when you ask, and ideally, you never do, you simply allow the goodwill to continue to compound.

Allow the word of mouth to continue to grow to the point where you start receiving money probably far further in the future than you are now and what you are accustomed to doing. But in that future state, you can then look at the minimal amount that you're spending in order to distribute your message to advertise, to make known, and then you will see that you have significantly higher returns on your advertising efforts. It just took longer to get there.

And so understand the difference between branding and direct response and having a longer term perspective and looking at the OGS in the space or lack thereof, and the people who have transitioned from direct response to branding. I think that there is a lot of lessons that we can take from it. And this is just one of them that I wanted to share with you.

And if you're new to the channel, welcome to Mosey Nation. I said this earlier, but our portfolio is about $85 million a year. It's actually probably a little higher than that.

I just try to stay consistent, but I think it's probably over 100 now. But I make these videos because struggled a lot coming up and I hope that the pain that I went through is not for nothing. And so that's why I make these videos.

I just hope you like it. So anyways, keep being awesome. I'll see you guys in the next bit.

Bye.