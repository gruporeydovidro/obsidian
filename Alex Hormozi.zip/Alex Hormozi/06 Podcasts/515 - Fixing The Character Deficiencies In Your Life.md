Real quick, guys, if you can think about how you found this podcast, somebody probably tweeted it, told you about it, shared it on Instagram or something like that. The only way this grows is through word of mouth. And so I don't run ads, I don't do sponsorships, I don't sell anything.

My only ask is that you continue to pay it forward to whoever showed you or however you found out about this podcast that you do the exact same thing. So if it was a review, if it was a post, if you do that, it would mean the world to me, and you'll throw some good karma out there for another entrepreneur anxiety or happiness and depression or being a bad husband or being money focused or whatever. The thing is that you claim to have a problem with.

I want to give you really the only mental framework that has ever worked for me. Welcome to the game where we talk about how to get more customers, how to make more per customer and how to keep them longer, and the many failures and lessons we have learned along the way. I hope you enjoy and subscribe.

In this video, I'm going to be talking to you about how to fix the character traits and deficiencies that you have in your life. So whether that be struggling with anxiety or happiness and depression or being a bad husband or being money focused or whatever, the thing is that you claim to have a problem with, I want to give you really the only mental framework that has ever worked for me. All right? And so if you're new to the channel, my name is Alex from Ozzy.

I'm an acquisition.com. It's a portfolio of companies that's about $85 million a year and I have nothing to sell you. I make these videos because, candidly, I enjoy sharing some of the things that have helped us kind of get through things as we've grown, our companies.

And there are a lot of people who are broke, and I don't want you to be one of them. And so I'm going to probably piss a lot of people off in this video, so I'm going to give you a heads up. Second thing is, I will be cussing in this video.

So if you have kids around, I would say mute it or listen to it another time. Beyond that, let's dive in. So I was talking to an entrepreneur the other day and they were saying that they were having panic attacks, right? And they were struggling with this issue.

And what I want to do is walk you through the process that I was explaining to them. Now, at this point, the reason the panic attacks started for this entrepreneur, ironically, is that they were talking to a therapist. And the therapist was like, let's look at your past, and dug up crap about their past.

And then they started looking at this thing and then they started getting anxiety, kind of remembering all these kind of past experiences and whatnot. Now, here's the thing. Most therapists and I say this with zero degree, but I think most people, most therapists are humans, and most humans suck at most things, especially things they think they're good at.

And so most of them are just normal people who did okay in school and now just, like, talking to people and don't have any fucking clue what they're doing. All right, so here's the deal. Here's the hot take.

What most of them will do is they will try and pull something up and say something to the extent of what do you make that mean? What does that mean to you? Right? And the thought process behind this is, hey, you have this thing. It's triggering a feeling because you think that having anxiety makes you a bad person or makes you a bad entrepreneur or whatever thing that you say it has meaning, right? What do we make this mean? All right, that's the question. What are you making this mean? All right, so if you have problems and this is especially important with cyclical behavior, reinforcing behavior, this is also one of the reasons that I actually do not stand for the whole AA concept of standing up in front of people every morning and say, Hi, everybody, I am an addict.

I fucking hate it. It's literally like owning this deficiency and incorporating it and weaving it into your construct and your identity, and you reinforce it every fucking morning. It's insanity.

To me, the way to stop being addicted to something is to stop thinking about it. Like, what does it look like to not be addicted? Right? It looks like you just continuing to live your life not even thinking about it. What does it look like to not have anxiety? It's not you doing your antianxiety routine in the morning and saying, I suffer from anxiety or I struggle with anxiety.

It's not saying that and saying, I have to do these things. I must, I should, I need to in order to not have anxiety. Because then you're thinking about anxiety.

You give anxiety power. And so what I'm going to walk you through is the way to hold the space and own the power that you have in your own mind outside of the thing that you were projecting the power onto, all right? So the process that these therapists that are fucking retards will do is they will lead you through this thing where they try and transform meaning. They say instead of saying it means you're a bad person, what if we just said it's a good thing or it's not a bad thing? Right.

So we try and transform meaning. And I think that's like level one elementary grade school of cognitive behavioral therapy, right? I think that's grade school. Right.

But the thing is and this is the problem, because I've gone through the cycle, which is why I'm speaking about this so passionately, all right? And I'll tell you a quick story before I dive in. So there was a period of time in my life where I was very unhappy, all right? And so I obsessed about happiness, right? I read all the positive psychology journals. I read the books.

I read the happiness equation. I went through all of these things. And yet, after spending all of this time trying to obsess about happiness, I was no more happy, right? And so then I thought to myself, well, in one instance, I can spend lots of time and effort and be unhappy, or I can spend zero time and effort and be unhappy.

Well, this one cost me less. I might as well start pursuing this. And this is what happened.

I adopted this mentality, and I will share it with you called fuck happiness, all right? Bear with me. And so what ended up happening is that I thought these thoughts, and whenever the idea is this making me happy and all of these normal trigger thoughts, I'd be like, oh, I'm not happy. This isn't good.

I feel sad. Blah, blah, blah. I would literally have this trump card that would just pop in my head and be like, fuck happiness.

And I keep moving, right? And so the difference between fuck happiness and let's think about how we should be grateful for things is that when you say fuck happiness or fuck the thing that you are struggling with, fuck anxiety, fuck, whatever, is that it no longer has power. Because we're not trying to transform the meaning of the behavior. We are eliminating the meaning behind it altogether.

We are transforming it into nothing, into meaningless, all right? And so hear me out for a second. And I don't know why this is getting all spacey and weird. I've tried to fix this thing a hundred times.

Anyway, so the reason this is so important, all right, is that when you enter these vicious reinforcing cycles so let's say it's like, oh, God, I'm afraid I'm going to have a panic attack tonight. I don't want to have a panic attack. You start thinking about having a panic attack, and then of course you have a panic attack, right? Because the fear of the thing is what reinforces the cycle.

And you can do this with anything, right? It could be a guy with erectile dysfunction. Like, I hope it doesn't happen. I hope it doesn't happen.

And then it happens, right? Because you're worried about it happening, not because the happening itself is the thing, right? And I'm trying to use examples that purposefully people derive shame from, because the thing is that the shame of the occurrence is the thing that gives it power. And so if you remove the shame and by the way, the way to remove shame is to shed light on it. So nothing can give you shame if you admit it openly.

Think about it. If everyone knows the thing and you accept the thing or deem the thing meaningless, then it no longer has power for over you. So let me give you an example.

So this entrepreneur that I was talking about earlier, they were telling me that they're having anxiety attacks and it was preventing them from sleeping, et cetera, right? And I was like, So they're like, Well, I'm really working on it. And I was like, Why? And they looked at me cross eyed, and I was like, how long you been working this? They're, like, eight months. And I was like, Are you less anxious than you were before? They were like, Well, I think a little bit.

And I was like, do you think you would be a little bit less anxious if you just did jack shit and waited eight months from when you from when you were bad until now? They're like, well, maybe. I was like, Time does heal lots of wounds. I was like, So you spent all this time to get this little outcome, and you could have just let time happen and probably had the same outcome? Right? Right? I was like, but let's take it one step further.

Why didn't you tell me how many bowel movements you had yesterday? I didn't think it was relevant. Exactly. So why are you sharing with me that you have panic attacks? Because you think it's meaningful.

You derive meaning. Your brain is telling you that this is something that is a problem. So the thing is that the deeming of the thing, a problem is the problem, and trying to change it or transform the meaning into something else is, in my opinion, just as bad.

Because the way that you created the mess that you are in in a vicious cycle of reinforcement is that you found a thing and then you said, I will give this meaning. And then you spent the rest of your time trying to transform the meaning when if you want to solve the problem, the experience of having the problem solved is to not think about the problem at all. And so what it is, is actually reversing the process that created meaning to begin with, which is removing meaning altogether.

Hey, guys, real quick. For those of you guys who are 100 million dollar Offers fans, I love you. I added in a lost chapter that has never been released.

I'm releasing it now transparently. I'm doing that to build Hype for 100 million dollar leads. But you will have the unreleased chapter.

It talks about your first avatar and how to segment customers to make more money. You can get it by going to acquisition.com leads.

It's for free in exchange for your email so that I can email you when we launch 100 million dollar leads and so that you cannot miss out on it. Because last time I sold out for like eight straight weeks really fast. So that is my way of making sure that you all get first dibs.

I'm saying this because I've had so many things that I've struggled with in my life that I would consistently obsess about over and over and over. You know, oh, I don't want to have that happening yet. Oh, I don't want to have that happen again.

And then it would happen, right? And so in my opinion, the only way to overcome these issues is to you can slap the fuck happiness concept on it, but is to destroy the meaning of the thing itself and let it shrink into irrelevance. My opinion, most of the psychological problems that we deal with are better dealt with not by trying to directly combat them, but by not giving them the power of our attention. And there's a big difference here.

I'm not saying the thought of anxiety comes up and you say, oh, I don't want to think about it because then it's fear. Fear gives it power. Shame gives it power.

It's not that it's looking at it and saying, why are you bringing this up? This is irrelevant. This is a non issue. And so for the same reason that you can have noise in the background and you don't think about it is that it's just noise.

And so what we do is we shrink the thing from being a signal that our brain deems meaningful to noise that is in the background that we no longer ascribe meaning to altogether. And that is how it eventually shrinks into irrelevance. And then we only choose to allocate our attention towards the thing that we find meaningful, right? And so what happened in my little fuck happiness story is that I said, this is no longer a productive conversation.

I'd be like, I'm unhappy. I'd be like, fuck happiness, whatever. I'm going to keep moving.

And a funny thing happened a few years later. I looked up and I realized that I was significantly more happy than I was before. Or as I prefer to say, I was significantly less unhappy, which also gives less power to this thing altogether.

Right? Now, a different point that I want to bring up because I think it's equally important around this topic is that a lot of the fear and the shame comes from perceived judgment that we have from an anonymous outside society, right? We have a voice or a series of voices that we believe exist, that only exist in our mind that are judging us based on this behavior that we are suffering from, right? One of the reasons that I like to own the deficiencies publicly is not because of you guys. It's for me, I own, like, for example, when we're running and growing our first big business, which is the licensing business, I was always upfront. I said, I'm here to make money.

And the reason I said that was so that I would have no shame in making money. Because then if people in the future were going to say something like, alex is only here to make money, I would then look at them and say, and so hear me out. Listen to this dialogue.

Let's say I was attacked because the attacks that I'm saying, I'm going to portray as though it's outside, but it's inside of our minds that we attack ourselves, right? So let's say somebody comes up to me, a woman, and says, you're a terrible husband, right? Most people say that there are two forms of defense against this. Number one is saying, no, I'm not a bad husband, right, and then giving all the reasons why I'm a good husband, right. The other way to defend against that would be to say, well, being a husband is not necessarily such a bad thing, right.

And so one is to dispute. The other is to alter, right? We're altering the meaning behind the thing. The first is we're combating and we're saying that we're not the thing, but still allowing the thing to have meaning, allowing a bad husband to be a negative connotation that we ascribe meaning to.

I think this is meaningful and it's negative but meaningful. And so I will say I am not that thing. Or version two is this thing is meaningful, but I understand it and interpret differently.

Right? Those are the two ways. The second way is how most therapy works. And I also think that it's bullshit.

And so here's door number three, is that you look at the thing in the face and you say, and I think you're a bad husband. And you're right, and watch them shrivel. They will be paralyzed because everything that they have exists to have a counter force.

But if there is no counterforce for it to react to, the thought process stops. And so if you struggle with these vicious, reoccurring, consistent dialogues and arguments in your head about what's good and why should change and why you need to be different and why this shouldn't be this way, just look at it in the eyes and say, and I'm going to give you a really controversial example of what I think should have happened in a public scenario. Tiger woods, he was outed, you know what I mean, or ousted or whatever it is, you know what I mean? He was publicly shamed for the cheating thing, right? And mind you, this is not me condoning cheating.

This is me to illustrate a position of power. And this is a public demonstration of power. But you can take it in terms of how you can internally project that power onto the idea that you want to vanquish, all right? And we don't vanquish it by transforming it.

We vanquish it by eliminating the meaning altogether and letting it shrink into irrelevance. So what Tiger, in my opinion, should have done in that situation when they said you banged all these girls and you were lying and blah, blah, blah, blah. He should have said, yes, I'm a liar and a cheater, but I'm the best fucking golfer there is.

Next question. What do they say? When you accept it, there is no conversation. And so try this in the next argument you have with someone, a but more importantly with yourself, is that if someone says, I think you're X, Y and Z and you said, you're right.

Just give the power. Just say, sure, you're right. Now what? And so your point? When your brain tells you something that you don't like or that you don't want to look at, instead of trying to make it into something else, liken it to an irrelevant observation.

Brain, why didn't you bring up that I have brown hair? Because it doesn't matter. Brain, why didn't you bring up how many bowel movements I had yesterday? Because it doesn't matter. Brain, why didn't you say, tell me how many stairs I went up yesterday? Because it doesn't matter.

You don't find it meaningful. And so why am I now deeming this thing to be meaningful? It's irrelevant to me. It halts the conversation and it stops the cycle.

I say this and I know that I got passionate about this, but I say this as someone who struggled with this for a very long time. And so the only psychotherapy that I was able to do was on myself and it was not through talking out all of these things. And I know that a lot of people are going to get triggered.

A lot of people are going to say, hey, I have a therapist. They changed my life. Good for you.

That's awesome. Keep doing it. I don't care.

What I am doing is I'm trying to talk to people who have not had that or have done that and it and it did not work for them. All right? And so I'm sharing the single most powerful mental model that has worked for me, which is purposefully staring at the problem and saying, so what your move? And watch it shrivel and then moving on the fuck with your life. So anyways, I love you all.

MOSY nation. Appreciate you. Thank you for giving me the attention that you did today.

I make these videos because I hope that some of the lessons that have served me can serve some other people at least. And if you're in a darker place or you're struggling with something like anxiety or struggling with shame around some sort of activity that you have done, I can tell you the only way to struggle to deal with shame is to shed light on it. Shame only exists in darkness.

And the only way something has power is when we fight it because we deem it meaningful or worth combating. And so I think the only way to truly fight it is to not fight it at all and say it is not a fight worth having. And then it will evaporate.

And so anyways, my friends keeping awesome. Lots of love. I'll see you guys.

Bye, you.